from flask import Flask, render_template
import requests

main=Flask(__name__)
APOD_URL='https://api.nasa.gov/planetary/apod'
API='Beugeu9cW9A6nQxYmQrC0CShauzQ5t1BPbSSDgnj'

@main.route("/", methods=["GET"])
def index():
    par={"api_key":API}
    responce=requests.get(APOD_URL,params=par)
    data=responce.json()
    print(data)
    return render_template("index.html", apod=data)
if __name__ == "__main__":
    main.run(debug=False)